from django.shortcuts import render


from rest_framework import generics
from .models import *
from .serializers import TagsSerializer,NewSerializer,CategorySerializer
from rest_framework.permissions import IsAuthenticatedOrReadOnly,IsAuthenticated
from rest_framework.authentication import BasicAuthentication,SessionAuthentication

from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from .permissions import IsOwnerOrReadOnly
from .throttle import VisitThrottle
class NewList(generics.ListCreateAPIView):

    throttle_classes = [VisitThrottle]
    permission_classes = [IsAuthenticated,IsOwnerOrReadOnly]
    authentication_classes = [JSONWebTokenAuthentication]
    queryset = News.objects.all()
    serializer_class = NewSerializer

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

# from .throttle import UserThrottle
class NewDetail(generics.RetrieveUpdateDestroyAPIView):

    # throttle_classes = [UserThrottle]
    permission_classes = [IsAuthenticated,IsOwnerOrReadOnly]
    authentication_classes = [JSONWebTokenAuthentication]

    queryset = News.objects.all()
    serializer_class = NewSerializer



class CategoryList(generics.ListCreateAPIView):

    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class CategoryDetail(generics.RetrieveUpdateDestroyAPIView):

    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class TagsList(generics.ListCreateAPIView):

    queryset = Tags.objects.all()
    serializer_class = TagsSerializer
    def get_queryset(self): # 重写get_queryset返回不同版本的数据
        if self.request.version == 'v1':
            return Tags.objects.all()
        elif self.request.version == 'v2':
            return Tags.objects.exclude(id=1).all()


class TagsDetail(generics.RetrieveUpdateDestroyAPIView):


    queryset = Tags.objects.all()
    serializer_class = TagsSerializer


