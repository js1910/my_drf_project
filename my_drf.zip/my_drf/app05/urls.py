

from django.urls import path,include
from app05 import views
from rest_framework_jwt.views import obtain_jwt_token


urlpatterns = [
    path('tags/', views.TagsList.as_view(),name='tags-list'),
    path('tags/<int:pk>/', views.TagsDetail.as_view(),name='tags-detail'),

    path('news/', views.NewList.as_view(), name='new-list'),
    path('news/<int:pk>/', views.NewDetail.as_view(), name='new-detail'),

    path('category/', views.CategoryList.as_view(), name='category-list'),
    path('category/<int:pk>/', views.CategoryDetail.as_view(), name='category-detail'),

    path('api-token-auth/', obtain_jwt_token), # jwt验证
]
