from django.apps import AppConfig


class App05Config(AppConfig):
    name = 'app05'
