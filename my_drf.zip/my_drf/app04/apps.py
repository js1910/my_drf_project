from django.apps import AppConfig


class App04Config(AppConfig):
    name = 'app04'
