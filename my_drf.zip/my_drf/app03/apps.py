from django.apps import AppConfig


class App03Config(AppConfig):
    name = 'app03'
