from django.shortcuts import render
from .models import *
from .serializers import CrossSerializer,HotCrossSerializer,PicturesCrossSerializer
# Create your views here.



from .custom_model_view_set import CustomModelViewSet

class CrossSet(CustomModelViewSet):

        queryset = Cross.objects.all()
        serializer_class = CrossSerializer


class HotCrossSet(CustomModelViewSet):

        queryset = HotCross.objects.all()
        serializer_class = HotCrossSerializer


class PicturesCrossSet(CustomModelViewSet):

        queryset = PicturesCross.objects.all()
        serializer_class = PicturesCrossSerializer


