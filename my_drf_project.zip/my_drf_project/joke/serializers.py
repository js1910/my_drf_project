from rest_framework import serializers
from .models import Cross,HotCross,PicturesCross

class CrossSerializer(serializers.ModelSerializer):

    # updated_time = serializers.DateTimeField(format='%Y-%s-$d',read_only=True)
    # created_time = serializers.DateTimeField(format='%Y-%s-$d',read_only=True)
    # isdelete = serializers.SerializerMethodField(read_only=True)
    class Meta:
        model = Cross
        fields = '__all__'

    def get_isdelete(self,obj):
        # if obj.isdelete:
        #     return 1
        # else:
        #     return 0
        return 1 if obj.isdelete else 0

class PicturesCrossSerializer(serializers.ModelSerializer):

    # updated_time = serializers.DateTimeField(format='%Y-%s-$d',read_only=True)
    # created_time = serializers.DateTimeField(format='%Y-%s-$d',read_only=True)
    # isdelete = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = PicturesCross
        fields = '__all__'


    def get_isdelete(self,obj):
        if obj.isdelete:
            return 1
        else:
            return 0
        # return 1 if obj.isdelete else 0

    def to_representation(self, instance):
        representation = super(PicturesCrossSerializer,self).to_representation(instance)
        representation['cover'] = PicturesCrossSerializer(instance.cover)
        # representation['cover'] = instance.

        return representation


class HotCrossSerializer(serializers.ModelSerializer):

    # updated_time = serializers.DateTimeField(format='%Y-%s-$d',read_only=True)
    # created_time = serializers.DateTimeField(format='%Y-%s-$d',read_only=True)
    isdelete = serializers.SerializerMethodField(read_only=True)
    istop = serializers.SerializerMethodField(read_only=True)
    class Meta:
        model = HotCross
        fields = '__all__'

    def get_isdelete(self,obj):
        # if obj.isdelete:
        #     return 1
        # else:
        #     return 0
        return 1 if obj.isdelete else 0
    def get_istop(self,obj):
        return 1 if obj.istop else 0




















