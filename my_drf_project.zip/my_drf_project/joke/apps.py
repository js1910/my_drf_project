from django.apps import AppConfig


class JokeConfig(AppConfig):
    name = 'joke'
