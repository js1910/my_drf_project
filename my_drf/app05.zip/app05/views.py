from django.shortcuts import render


from rest_framework import generics
from .models import *
from .serializers import TagsSerializer,NewSerializer,CategorySerializer
from rest_framework.permissions import IsAuthenticatedOrReadOnly,IsAuthenticated
from rest_framework.authentication import BasicAuthentication,SessionAuthentication

# from rest_framework_jwt.authentication import JSONWebTokenAuthentication
# from .permissions import IsOwnerOrReadOnly

class NewList(generics.ListCreateAPIView):
    # # 局部认证大于全局认证
    # permission_classes = [IsAuthenticated] # 用户存在并且是激活的状态
    # # authentication_classes = [SessionAuthentication] # 采用session加密认证
    # authentication_classes = [BasicAuthentication] # 采用base64加密认证
    queryset = News.objects.all()
    serializer_class = NewSerializer


class NewDetail(generics.RetrieveUpdateDestroyAPIView):
    #
    # permission_classes = [IsAuthenticatedOrReadOnly,IsOwnerOrReadOnly,]
    # authentication_classes = [JSONWebTokenAuthentication]
    queryset = News.objects.all()
    serializer_class = NewSerializer

class CategoryList(generics.ListCreateAPIView):
    # # 局部认证大于全局认证
    # permission_classes = [IsAuthenticated] # 用户存在并且是激活的状态
    # # authentication_classes = [SessionAuthentication] # 采用session加密认证
    # authentication_classes = [BasicAuthentication] # 采用base64加密认证
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class CategoryDetail(generics.RetrieveUpdateDestroyAPIView):
    #
    # permission_classes = [IsAuthenticatedOrReadOnly,IsOwnerOrReadOnly,]
    # authentication_classes = [JSONWebTokenAuthentication]
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class TagsList(generics.ListCreateAPIView):
    # # 局部认证大于全局认证
    # permission_classes = [IsAuthenticated] # 用户存在并且是激活的状态
    # # authentication_classes = [SessionAuthentication] # 采用session加密认证
    # authentication_classes = [BasicAuthentication] # 采用base64加密认证
    queryset = Tags.objects.all()
    serializer_class = TagsSerializer


class TagsDetail(generics.RetrieveUpdateDestroyAPIView):
    #
    # permission_classes = [IsAuthenticatedOrReadOnly,IsOwnerOrReadOnly,]
    # authentication_classes = [JSONWebTokenAuthentication]
    queryset = Tags.objects.all()
    serializer_class = TagsSerializer


