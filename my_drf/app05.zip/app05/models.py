from django.db import models

# Create your models here.

class Category(models.Model):
    desc = models.CharField(verbose_name='分类',max_length=10)

class Tags(models.Model):
    tag = models.CharField(verbose_name='标签',max_length=10)


class News(models.Model):
    title = models.CharField(verbose_name='标题',max_length=20)
    content = models.CharField(verbose_name='内容',max_length=400)

    category = models.ForeignKey(verbose_name='分类',to=Category,on_delete=models.CASCADE)
    tags = models.ManyToManyField(verbose_name='标签',to=Tags)











